package com.hashconcepts.composebmicalculator.ui.screens

sealed class Screens(val route: String) {
    object HomeScreen: Screens("Home")
    object ResultScreen: Screens("Result")

    fun withArgs(vararg args: String): String {
        return buildString {
            append(route)
            args.forEach { arg ->
                append("/$arg")
            }
        }
    }
}