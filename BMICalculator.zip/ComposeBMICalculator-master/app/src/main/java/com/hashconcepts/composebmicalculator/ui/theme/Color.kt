package com.hashconcepts.composebmicalculator.ui.theme

import androidx.compose.ui.graphics.Color


val Teal200 = Color(0xFF03DAC5)
val TextWhite = Color(0xffeeeeee)
val DeepBlue = Color(0xFF6A1B9A)
val ButtonBlue = Color(0xFF310B47)
val AquaBlue = Color(0xff9aa5c4)